package com.dngwjy.infinite.sokongbencana.data.shared

class Preferences {
}