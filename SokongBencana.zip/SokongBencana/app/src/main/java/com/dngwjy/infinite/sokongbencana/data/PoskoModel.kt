package com.dngwjy.infinite.sokongbencana.data

data class PoskoModel(
    var namaPosko:String
)